import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SelectimagePageRoutingModule } from './selectimage-routing.module';

import { SelectimagePage } from './selectimage.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SelectimagePageRoutingModule
  ],
  declarations: [SelectimagePage]
})
export class SelectimagePageModule {}
