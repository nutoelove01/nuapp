import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SelectimagePage } from './selectimage.page';

const routes: Routes = [
  {
    path: '',
    component: SelectimagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SelectimagePageRoutingModule {}
