import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selectimage',
  templateUrl: './selectimage.page.html',
  styleUrls: ['./selectimage.page.scss'],
})
export class SelectimagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
