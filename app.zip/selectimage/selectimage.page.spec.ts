import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SelectimagePage } from './selectimage.page';

describe('SelectimagePage', () => {
  let component: SelectimagePage;
  let fixture: ComponentFixture<SelectimagePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectimagePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SelectimagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
